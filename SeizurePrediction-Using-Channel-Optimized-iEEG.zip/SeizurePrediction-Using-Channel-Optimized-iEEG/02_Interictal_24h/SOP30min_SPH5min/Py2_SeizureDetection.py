# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 14:20:11 2024
@author: User
"""

# In[]
from keras.layers import Input
from keras.layers import Conv1D, BatchNormalization, MaxPooling1D, concatenate
from keras.layers import GlobalAveragePooling1D, Dense, Activation, Dropout
from keras.models import Model

def OneDCNN_model(length,channels):
    NumKernel = 32;
    input_layer = Input(shape=(length, channels))

    # 第一个1DCNN模型
    model1 = Conv1D(NumKernel,3,strides=2,padding='same')(input_layer)
    model1 = Activation('relu')(model1)
    model1 = BatchNormalization()(model1)
    model1 = MaxPooling1D(3,strides=2,padding='same')(model1)
    
    model1 = Conv1D(NumKernel,3,strides=2,padding='same')(model1)
    model1 = Activation('relu')(model1)
    model1 = BatchNormalization()(model1)
    model1 = MaxPooling1D(3,strides=2,padding='same')(model1)
    
    model1 = Conv1D(2*NumKernel,3,strides=2,padding='same')(model1)
    model1 = Activation('relu')(model1)
    model1 = BatchNormalization()(model1)
    model1 = MaxPooling1D(3,strides=2,padding='same')(model1)
    
    model1 = Conv1D(4*NumKernel,3,strides=1,padding='same')(model1)
    model1 = Activation('relu')(model1)
    model1 = BatchNormalization()(model1)
    model1 = MaxPooling1D(3,strides=2,padding='same')(model1)

    # 第二个1DCNN模型
    model2 = Conv1D(NumKernel,5,strides=2,padding='same')(input_layer)
    model2 = Activation('relu')(model2)
    model2 = BatchNormalization()(model2)
    model2 = MaxPooling1D(3,strides=2,padding='same')(model2)
    
    model2 = Conv1D(NumKernel,5,strides=2,padding='same')(model2)
    model2 = Activation('relu')(model2)
    model2 = BatchNormalization()(model2)
    model2 = MaxPooling1D(3,strides=2,padding='same')(model2)
    
    model2 = Conv1D(2*NumKernel,5,strides=2,padding='same')(model2)
    model2 = Activation('relu')(model2)
    model2 = BatchNormalization()(model2)
    model2 = MaxPooling1D(3,strides=2,padding='same')(model2)
    
    model2 = Conv1D(4*NumKernel,5,strides=1,padding='same')(model2)
    model2 = Activation('relu')(model2)
    model2 = BatchNormalization()(model2)
    model2 = MaxPooling1D(3,strides=2,padding='same')(model2)
    
    # 合并两个模型
    x = concatenate([model1,model2])
    x = GlobalAveragePooling1D()(x)
    
    # 全连接层
    x = Dense(256,activation='relu')(x)
    x = Dropout(0.25)(x)
    x = Dense(128,activation='relu')(x)
    output_layer = Dense(2,activation='sigmoid')(x)

    model = Model(inputs=input_layer,outputs=output_layer)
    model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
    return model

# In[]
import os, gc
import h5py
import numpy as np
from keras.utils import np_utils
from keras.callbacks import EarlyStopping
import scipy.io as sio
from keras import backend as K
from tensorflow.compat.v1 import reset_default_graph

def create_folder_if_not_exists(NewPath):
    if not os.path.exists(NewPath):
        os.makedirs(NewPath)
        print(f"文件夹 '{NewPath}' 已创建。")
    else:
        print(f"文件夹 '{NewPath}' 已存在，跳过创建。")

early_stopping = EarlyStopping(monitor='val_loss',patience=10,verbose=1,restore_best_weights=True) 
Path = 'F:/01_SWEC-ETHZ_LongTerm/Interictal_24h/SOP30min_SPH5min/' ###

Folders = ['ID_03/','ID_05/','ID_06/','ID_07/','ID_08/','ID_12/','ID_13/','ID_14/','ID_16/','ID_18/']
NumFolder = len(Folders)
NumRun = 2

for FoldersNum in range(1,2):
    Route = Path+Folders[FoldersNum]
    mat_files = [f for f in os.listdir(Route) if f.endswith('.mat')]
    NumMat = len(mat_files)
    
    NewPath = Path+'DetectionLabels/'+Folders[FoldersNum]
    create_folder_if_not_exists(NewPath)
    
    for MatNum in range(0,NumMat):
        MatPath = Route+mat_files[MatNum]
        Data = h5py.File(MatPath,'r')
        X = Data['TrainTest']
        
        Train = Data[X[0][0]][:]
        print(np.shape(Train))
        length = len(Train[0,:,0])
        NumChan = len(Train[0,0,:])
        
        Label = Data[X[1][0]]
        Label = np.transpose(Label,[1,0])
        Label_Train = np_utils.to_categorical(Label)
        
        Label_Test = Data[X[3][0]]
        Label_Test = np.transpose(Label_Test,[1,0])
        samps = len(Label_Test)
        Label_Test = np.squeeze(Label_Test)
        Pred_Labels = np.zeros((samps,4,NumChan+1,NumRun))
        
        Test = Data[X[2][0]][:]
        
        del X
        gc.collect()
        del Data
        gc.collect()
        del Label
        gc.collect()
                
        modelAllChan = OneDCNN_model(length,NumChan)
        modelOneChan = OneDCNN_model(length,1)
        for RunNum in range(0,NumRun):
            modelAllChan.fit(Train,Label_Train,epochs=100,batch_size=64,validation_split=0.15,
                      callbacks=[early_stopping])
            K.clear_session()
            
            Label_Prob = modelAllChan.predict(Test)
            K.clear_session()
            labels = np.argmax(Label_Prob, axis=1)
            
            Pred_Labels[:,0:2,0,RunNum] = Label_Prob
            Pred_Labels[:,2,0,RunNum] = labels
            Pred_Labels[:,3,0,RunNum] = Label_Test
            
            for ChanNum in range(0,NumChan):
                modelOneChan.fit(Train[:,:,ChanNum],Label_Train,epochs=100,batch_size=64,validation_split=0.15,
                          callbacks=[early_stopping])
                K.clear_session()
                
                Label_Prob = modelOneChan.predict(Test[:,:,ChanNum])
                labels = np.argmax(Label_Prob, axis=1)
                K.clear_session()
                
                Pred_Labels[:,0:2,ChanNum+1,RunNum] = Label_Prob
                Pred_Labels[:,2,ChanNum+1,RunNum] = labels
                Pred_Labels[:,3,ChanNum+1,RunNum] = Label_Test
        
        NewRoute = NewPath+'PredLabels_'+mat_files[MatNum]
        sio.savemat(NewRoute,{'PredLabels':Pred_Labels})
        
        del Train
        gc.collect()
        del Label_Train
        gc.collect()
        del Test
        gc.collect()
        del Label_Test
        gc.collect()
        del Pred_Labels
        gc.collect()
        del Label_Prob
        gc.collect()
        del labels
        gc.collect()
        del modelAllChan
        gc.collect()
        del modelOneChan
        gc.collect()
        K.clear_session()
        reset_default_graph()

# In[]
        