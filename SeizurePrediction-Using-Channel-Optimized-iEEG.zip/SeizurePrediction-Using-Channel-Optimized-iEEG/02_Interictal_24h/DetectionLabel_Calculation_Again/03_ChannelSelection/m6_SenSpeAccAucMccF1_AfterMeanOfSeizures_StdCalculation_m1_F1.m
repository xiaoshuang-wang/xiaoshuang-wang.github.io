clc
clear
close all
tic

%%
SSAAMF = load('m1_SenSpeAccAucMccF1_F1.mat');
SSAAMF = struct2cell(SSAAMF);
SSAAMF = SSAAMF{1,1};
[NumPatient,NumSopType] = size(SSAAMF);

for SopTypeNum = 1:NumSopType
    for PatientNum = 1:NumPatient
        TempSSAAMF  = SSAAMF{PatientNum,SopTypeNum};
        TempMeanSSAFMA(PatientNum,:) = mean(TempSSAAMF,1);
        TempStdSSAFMA(PatientNum,:) = std(TempSSAAMF,1,1);
    end
    TempMeanSSAFMA = roundn(TempMeanSSAFMA,-3);
    TempStdSSAFMA = roundn(TempStdSSAFMA,-3);

    TempMeanSSAFMA(PatientNum+1,:) = mean(TempMeanSSAFMA,1);
    TempMeanSSAFMA = roundn(TempMeanSSAFMA,-3);

    TempStdSSAFMA(PatientNum+1,:) = std(TempMeanSSAFMA,1,1);
    TempStdSSAFMA = roundn(TempStdSSAFMA,-3);

    TempMeanSSAFMA(:,[1:3]) = TempMeanSSAFMA(:,[1:3])*100;
    TempStdSSAFMA(:,[1:3]) = TempStdSSAFMA(:,[1:3])*100;

    for i = 1:size(TempStdSSAFMA,2)
        TempMeanStdSSAFMA(:,2*i-1) = TempMeanSSAFMA(:,i);
         TempMeanStdSSAFMA(:,2*i) = TempStdSSAFMA(:,i);
    end

    MeanStdSSAAMF{SopTypeNum,1} = TempMeanStdSSAFMA;
    clear TempMeanSSAFMA TempStdSSAFMA TempMeanStdSSAFMA
end
save('m6_MeanStdSSAAMF_m1_F1','MeanStdSSAAMF')

%%
toc
