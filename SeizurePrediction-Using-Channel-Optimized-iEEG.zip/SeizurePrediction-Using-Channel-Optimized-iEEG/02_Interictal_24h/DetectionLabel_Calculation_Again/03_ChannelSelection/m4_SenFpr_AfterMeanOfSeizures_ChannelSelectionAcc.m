clc
clear
close all
tic

%%
SF = load('m3_SenFpr_Acc.mat'); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SF = struct2cell(SF);
SF = SF{1,1};
[NumPatient,NumSopType] = size(SF);
HourInterictal = 24; %%%%%%%%%%********** 24 h **********%%%%%%%%%%

for SopTypeNum = 1:NumSopType
    for PatientNum = 1:NumPatient
        TempSF  = SF{PatientNum,SopTypeNum};
        NumSeizureTruePred(PatientNum,1) = length(TempSF);
        NumSeizureTruePred(PatientNum,2) = sum(TempSF(:,1));
        TempSenFpr(PatientNum,1) = mean(TempSF(:,1));
        TempSenFpr(PatientNum,2) = sum(TempSF(:,2))/HourInterictal;
    end
    TempSenFpr(:,1) = roundn(TempSenFpr(:,1),-3);
    TempSenFpr(:,2) = roundn(TempSenFpr(:,2),-2);
    AllSen = sum(NumSeizureTruePred(:,2))/sum(NumSeizureTruePred(:,1));
    AllSen = roundn(AllSen,-3);
    AllFpr = mean(TempSenFpr(:,2));
    AllFpr = roundn(AllFpr,-2);
    TempSenFpr(PatientNum+1,:) = [AllSen,AllFpr];
    TempSenFpr(:,1) = TempSenFpr(:,1)*100;
    MeanSenFpr{SopTypeNum,1} = TempSenFpr;
end
save('m4_MeanSenFpr_Acc','MeanSenFpr') %%%%%%%%%%%%%%%%%%%%%%%%%

%%
toc
