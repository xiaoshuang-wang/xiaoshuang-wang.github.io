clc
clear
close all
tic

%%
SopSphFolder = {'SOP30min_SPH5min';'SOP60min_SPH5min';'SOP90min_SPH5min'};
DetectionLabelFolder = 'DetectionLabels';
PatientFolder = {'ID_03';'ID_05';'ID_06';'ID_07';'ID_08';'ID_12';'ID_13';'ID_14';'ID_16';'ID_18'};

NumSopSphType = length(SopSphFolder);
NumPatient = length(PatientFolder);
for SopSphTypeNum = 1:NumSopSphType
    for PatientNum = 1:NumPatient
        Path = strcat('..',filesep,'..',filesep,SopSphFolder{SopSphTypeNum,1},filesep,...
            DetectionLabelFolder,filesep,PatientFolder{PatientNum,1},filesep);
        MatInfo = dir(fullfile(Path,'*.mat'));
        MatNames = {MatInfo.name}';
        NumMat = length(MatNames);
        TempAuc = [];
        for MatNum = 1:NumMat
            MatPath = strcat(Path,MatNames{MatNum,1});
            Labels = load(MatPath);
            Labels = struct2cell(Labels);
            Labels = cell2mat(Labels);
            [NumSamp,NumType,NumChanType,NumRun] = size(Labels);
            for RunNum = 1:NumRun
                for ChanTypeNum = 2:NumChanType %%%%%%%%%%%%%%%%%%%%%%
                    PredLabel = [];
                    TrueLabel = [];
                    PredLabel = Labels(:,NumType-1,ChanTypeNum,RunNum);
                    TrueLabel = Labels(:,NumType,ChanTypeNum,RunNum);

                    [X, Y, T, TmpAuc] = perfcurve(TrueLabel,PredLabel,1);

                    TempAuc(ChanTypeNum-1,MatNum,RunNum) = TmpAuc; % for AUC
                end
            end
        end
        AUC{PatientNum,SopSphTypeNum} = squeeze(mean(TempAuc,2));
    end
end

%%
for SopSphTypeNum = 1:NumSopSphType
    for PatientNum = 1:NumPatient
        TempAuc = AUC{PatientNum,SopSphTypeNum};
        [NumChan,NumRun] = size(TempAuc);
        for RunNum = 1:NumRun
            [B,TempIndex] = sort(TempAuc(:,RunNum),'descend');
            Index(:,RunNum) = TempIndex;
            TempIndex = [];
        end
        Dindex{PatientNum,SopSphTypeNum} = Index;
        Index = [];
    end
end
save('m0_Dindex','Dindex')

%%
toc
