clc
clear
close all
tic

%%
SopSphFolder = {'SOP30min_SPH5min';'SOP60min_SPH5min';'SOP90min_SPH5min'};
DetectionLabelFolder = 'DetectionLabels';
PatientFolder = {'ID_03';'ID_05';'ID_06';'ID_07';'ID_08';'ID_12';'ID_13';'ID_14';'ID_16';'ID_18'};

Dindex = load('m0_Dindex_Acc.mat'); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Dindex = struct2cell(Dindex);
Dindex = Dindex{1,1};

NumSopSphType = length(SopSphFolder);
NumPatient = length(PatientFolder);
for SopSphTypeNum = 1:NumSopSphType
    for PatientNum = 1:NumPatient
        Path = strcat('..',filesep,'..',filesep,SopSphFolder{SopSphTypeNum,1},filesep,...
            DetectionLabelFolder,filesep,PatientFolder{PatientNum,1},filesep);
        MatInfo = dir(fullfile(Path,'*.mat'));
        MatNames = {MatInfo.name}';
        NumMat = length(MatNames);
        TempDindex = Dindex{PatientNum,SopSphTypeNum};
        for MatNum = 1:NumMat
            MatPath = strcat(Path,MatNames{MatNum,1});
            Labels = load(MatPath);
            Labels = struct2cell(Labels);
            Labels = cell2mat(Labels);
            Labels(:,:,1,:) = []; %%%%%%%%%%%%%%%%%%%%%%%%%
            [NumSamp,NumType,NumChanType,NumRun] = size(Labels);

            for RunNum = 1:NumRun
                for ChanTypeNum = 1:NumChanType
                    PredLabel = [];
                    TrueLabel = [];
                    PredLabel = mean(Labels(:,NumType-1,TempDindex(1:ChanTypeNum,RunNum),RunNum),3); %%%%%%
                    PredLabel = double(PredLabel >= 0.5); %%%%%%
                    TrueLabel = Labels(:,NumType,1,RunNum);
                    CM = confusionmat(TrueLabel,PredLabel);
                    TN = CM(1,1);
                    FP = CM(1,2);
                    FN = CM(2,1);
                    TP = CM(2,2);

                    TempSenSpeAccAucMccF1(MatNum,1,ChanTypeNum,RunNum) = TP/(TP+FN); % for Sen
                    TempSenSpeAccAucMccF1(MatNum,2,ChanTypeNum,RunNum) = TN/(TN+FP); % for Spe
                    TempSenSpeAccAucMccF1(MatNum,3,ChanTypeNum,RunNum) = (TN+TP)/sum(CM(:)); % for Acc

                    [X, Y, T, AUC] = perfcurve(TrueLabel,PredLabel,1);
                    TempSenSpeAccAucMccF1(MatNum,4,ChanTypeNum,RunNum) = AUC; % for AUC

                    Numerator = TP*TN-FP*FN;
                    Denominator = sqrt((TP+FP)*(TP + FN)*(TN + FP)*(TN + FN));
                    if Denominator == 0
                        MCC = 0; %% 避免分母为0的情况
                    else
                        MCC = Numerator/Denominator;
                    end
                    TempSenSpeAccAucMccF1(MatNum,5,ChanTypeNum,RunNum) = MCC; % for MCC

                    TempSenSpeAccAucMccF1(MatNum,6,ChanTypeNum,RunNum) = 2*TP/(2*TP+FP+FN); % for F1

                end
            end
        end

        %%% Select Best Running
        TempMeanSenSpeAccAucMccF1 = squeeze(mean(TempSenSpeAccAucMccF1,1));
        AccRun1 = TempMeanSenSpeAccAucMccF1(3,:,1)'; %%%% 以Acc来判断最优Running
        [maxAccRun1, ChannumRun1] = max(AccRun1);
        AccRun2 = TempMeanSenSpeAccAucMccF1(3,:,2)'; %%%% 以Acc来判断最优Running
        [maxAccRun2, ChannumRun2] = max(AccRun2);

        if maxAccRun1>maxAccRun2
            for MatNum = 1:NumMat
                SenSpeAccAucMccF1Select(MatNum,:) = TempSenSpeAccAucMccF1(MatNum,:,ChannumRun1,1);
            end
            BestChanNum(PatientNum,SopSphTypeNum) = ChannumRun1;
            BestRun(PatientNum,SopSphTypeNum) = 1;
        else
            for MatNum = 1:NumMat
                SenSpeAccAucMccF1Select(MatNum,:) = TempSenSpeAccAucMccF1(MatNum,:,ChannumRun2,2);
            end
            BestChanNum(PatientNum,SopSphTypeNum) = ChannumRun2;
            BestRun(PatientNum,SopSphTypeNum) = 2;
        end

        SenSpeAccAucMccF1{PatientNum,SopSphTypeNum} = SenSpeAccAucMccF1Select;
        clear TempSenSpeAccAucMccF1 SenSpeAccAucMccF1Select
    end
end
save('m1_SenSpeAccAucMccF1_Acc','SenSpeAccAucMccF1')
save('m1_BestChanNumRun_Acc','BestChanNum','BestRun')

%%
toc