clc
clear
close all
tic

%%
MeanSSAAMF = load('m2_MeanSSAAMF_Acc.mat');
MeanSSAAMF = struct2cell(MeanSSAAMF);
MeanSSAAMF = MeanSSAAMF{1,1};
MeanSenFpr = load('m4_MeanSenFpr_Acc.mat');
MeanSenFpr = struct2cell(MeanSenFpr);
MeanSenFpr = MeanSenFpr{1,1};

for SopTypeNum = 1:length(MeanSSAAMF)
    TempSeg = MeanSSAAMF{SopTypeNum,1};
    TempEvent = MeanSenFpr{SopTypeNum,1};
    SegmentEvent_ChannelSelection{SopTypeNum,1} = [TempSeg(:,1:6),TempEvent]; %%%%%%%%%
end
save('m5_SegmentEvent_Acc','SegmentEvent_ChannelSelection')

%%
toc