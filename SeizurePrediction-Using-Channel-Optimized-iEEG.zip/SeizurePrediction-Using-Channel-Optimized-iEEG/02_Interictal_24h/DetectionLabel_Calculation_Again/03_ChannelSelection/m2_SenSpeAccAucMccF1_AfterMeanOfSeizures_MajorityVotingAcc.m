clc
clear
close all
tic

%%
SSAAMF = load('m1_SenSpeAccAucMccF1_Acc.mat'); %%%%%%%%%%%%%%%%%%%
SSAAMF = struct2cell(SSAAMF);
SSAAMF = SSAAMF{1,1};
[NumPatient,NumSopType] = size(SSAAMF);

for SopTypeNum = 1:NumSopType
    for PatientNum = 1:NumPatient
        TempSSAAMF  = SSAAMF{PatientNum,SopTypeNum};
        TempMeanSSAFMA(PatientNum,:) = mean(TempSSAAMF,1);
    end
    TempMeanSSAFMA = roundn(TempMeanSSAFMA,-3);
    TempMeanSSAFMA(PatientNum+1,:) = mean(TempMeanSSAFMA,1);
    TempMeanSSAFMA = roundn(TempMeanSSAFMA,-3);
    TempMeanSSAFMA(:,[1:3]) = TempMeanSSAFMA(:,[1:3])*100;
    MeanSSAAMF{SopTypeNum,1} = TempMeanSSAFMA;
    clear TempMeanSSAFMA
end
save('m2_MeanSSAAMF_Acc','MeanSSAAMF') %%%%%%%%%%%%%%%%%%%%%%%

%%
toc