clc
clear
close all
tic

%%
SopSphFolder = {'SOP30min_SPH5min';'SOP60min_SPH5min';'SOP90min_SPH5min'};
DetectionLabelFolder = 'DetectionLabels';
PatientFolder = {'ID_03';'ID_05';'ID_06';'ID_07';'ID_08';'ID_12';'ID_13';'ID_14';'ID_16';'ID_18'};

for SopSphFolderNum = 1:length(SopSphFolder)
    for PatientNum = 1:length(PatientFolder)
        Path = strcat('..',filesep,'..',filesep,SopSphFolder{SopSphFolderNum,1},filesep,...
            DetectionLabelFolder,filesep,PatientFolder{PatientNum,1},filesep);
        MatInfo = dir(fullfile(Path,'*.mat'));
        MatNames = {MatInfo.name}';
        NumMat = length(MatNames);
        for MatNum = 1:NumMat
            MatPath = strcat(Path,MatNames{MatNum,1});
            Labels = load(MatPath);
            Labels = struct2cell(Labels);
            Labels = cell2mat(Labels);
            [NumSamp,NumType,NumChanType,NumRun] = size(Labels);
            for RunNum = 1:NumRun
                Prob1 = [];
                Prob2 = [];
                Prob1 = mean(Labels(:,1,2:NumChanType,RunNum),3); %%%%%%
                Prob2 = mean(Labels(:,2,2:NumChanType,RunNum),3); %%%%%%
                PredLabel = [];
                TrueLabel = [];
                PredLabel = double(Prob1 <= Prob2); 
                TrueLabel = Labels(:,NumType,1,RunNum);
                CM = confusionmat(TrueLabel,PredLabel);
                TN = CM(1,1);
                FP = CM(1,2);
                FN = CM(2,1);
                TP = CM(2,2);

                TempSenSpeAccAucMccF1(MatNum,1,RunNum) = TP/(TP+FN); % for Sen
                TempSenSpeAccAucMccF1(MatNum,2,RunNum) = TN/(TN+FP); % for Spe
                TempSenSpeAccAucMccF1(MatNum,3,RunNum) = (TN+TP)/sum(CM(:)); % for Acc

                [X, Y, T, AUC] = perfcurve(TrueLabel,PredLabel,1);
                TempSenSpeAccAucMccF1(MatNum,4,RunNum) = AUC; % for AUC

                Numerator = TP*TN-FP*FN;
                Denominator = sqrt((TP+FP)*(TP + FN)*(TN + FP)*(TN + FN));
                if Denominator == 0
                    MCC = 0; %% 避免分母为0的情况
                else
                    MCC = Numerator/Denominator;
                end
                TempSenSpeAccAucMccF1(MatNum,5,RunNum) = MCC; % for MCC

                TempSenSpeAccAucMccF1(MatNum,6,RunNum) = 2*TP/(2*TP+FP+FN); % for F1
            end
        end

        %%% Select Best Running
        for MatNum = 1:NumMat
            AucRun1 = TempSenSpeAccAucMccF1(MatNum,4,1); %% 以AUC来判断最优Running
            AucRun2 = TempSenSpeAccAucMccF1(MatNum,4,2); %% 以AUC来判断最优Running
            if AucRun1>AucRun2
                SenSpeAccAucMccF1Select(MatNum,:) = TempSenSpeAccAucMccF1(MatNum,:,1);
                TempRunIndex(MatNum,1) = 1;
            else
                SenSpeAccAucMccF1Select(MatNum,:) = TempSenSpeAccAucMccF1(MatNum,:,2);
                TempRunIndex(MatNum,1) = 2;
            end
        end
        SenSpeAccAucMccF1{PatientNum,SopSphFolderNum} = SenSpeAccAucMccF1Select;
        BestRunIndex{PatientNum,SopSphFolderNum} = TempRunIndex;
        clear TempSenSpeAccAucMccF1 SenSpeAccAucMccF1Select TempRunIndex
    end
end
save('m6_SenSpeAccAucMccF1','SenSpeAccAucMccF1')
save('m6_BestRunIndex','BestRunIndex')

%%
toc