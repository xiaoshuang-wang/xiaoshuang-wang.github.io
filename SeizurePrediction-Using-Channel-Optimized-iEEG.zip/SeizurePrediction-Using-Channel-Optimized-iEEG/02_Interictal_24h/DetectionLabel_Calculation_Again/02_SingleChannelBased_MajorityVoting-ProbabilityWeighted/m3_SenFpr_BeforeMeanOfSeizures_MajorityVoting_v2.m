clc
clear
close all
tic

%%
SopSphFolder = {'SOP30min_SPH5min';'SOP60min_SPH5min';'SOP90min_SPH5min'};
DetectionLabelFolder = 'DetectionLabels';
PatientFolder = {'ID_03';'ID_05';'ID_06';'ID_07';'ID_08';'ID_12';'ID_13';'ID_14';'ID_16';'ID_18'};
SOP = [30;60;90];
SPH = 5;
Window = 16; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Threshold = 12; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BestRunIndex = load('m1_BestRunIndex.mat');
BestRunIndex = struct2cell(BestRunIndex);
BestRunIndex = BestRunIndex{1,1};

for SopSphFolderNum = 1:length(SopSphFolder)
    IntervalSamp = (SOP(SopSphFolderNum)+SPH)*60/4;
    for PatientNum = 1:length(PatientFolder)
        Path = strcat('..',filesep,'..',filesep,SopSphFolder{SopSphFolderNum,1},filesep,...
            DetectionLabelFolder,filesep,PatientFolder{PatientNum,1},filesep);
        MatInfo = dir(fullfile(Path,'*.mat'));
        MatNames = {MatInfo.name}';
        NumMat = length(MatNames);
        TempRunIndex = BestRunIndex{PatientNum,SopSphFolderNum};
        for MatNum = 1:NumMat
            MatPath = strcat(Path,MatNames{MatNum,1});
            Labels = load(MatPath);
            Labels = struct2cell(Labels);
            Labels = cell2mat(Labels);
            [NumSamp,NumType,NumChanType,NumRun] = size(Labels);

            PredLabel = [];
            TrueLabel = [];
            PredLabel = mean(Labels(:,NumType-1,2:NumChanType,TempRunIndex(MatNum)),3); %%%%%%
            PredLabel = double(PredLabel >= 0.5); %%%%%%
            TrueLabel = Labels(:,NumType,1,TempRunIndex(MatNum));

            %%%%%%%********** For event-based sensitivity **********%%%%%%%%
            TrueIndex1 = [];
            TrueIndex1 = find(TrueLabel==1);
            PredLabel1 = PredLabel(TrueIndex1,1);
            TpNum = 0;
            for SampNum = Window:length(PredLabel1)
                Lstart = SampNum-Window+1;
                Lend = SampNum;
                ThresholdPred = sum(PredLabel1(Lstart:Lend,1));
                if ThresholdPred >= Threshold
                    TpNum = TpNum+1;
                end
            end

            if TpNum>0
                Sen = 1;
            else
                Sen = 0;
            end
            TempSenFpr(MatNum,1) = Sen;

            %%%%%%%********** For event-based FPR **********%%%%%%%%
            TrueIndex0 = [];
            TrueIndex0 = find(TrueLabel==0);
            PredLabel0 = PredLabel(TrueIndex0,1);
            FpNum = 0;
            PredFlag=0;
            countPred = 0;
            for SampNum = Window:length(PredLabel0)
                Lstart = SampNum-Window+1;
                Lend = SampNum;
                ThresholdPred = sum(PredLabel0(Lstart:Lend,1));
                if PredFlag ==0
                    if ThresholdPred >= Threshold
                        FpNum = FpNum+1;
                        PredFlag = 1;
                    end
                else
                    countPred = countPred+1;
                    if countPred >= IntervalSamp
                        PredFlag = 0;
                        countPred = 0;
                    end
                end
            end
            TempSenFpr(MatNum,2) = FpNum;
        end
        SenFpr{PatientNum,SopSphFolderNum} = TempSenFpr;
        clear TempSenFpr
    end
end
save('m3_SenFpr_v2','SenFpr')

%%
toc