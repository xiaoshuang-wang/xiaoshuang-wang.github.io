clc
clear
close all
tic

%%
MeanSSAAMF = load('m7_MeanSSAAMF.mat');
MeanSSAAMF = struct2cell(MeanSSAAMF);
MeanSSAAMF = MeanSSAAMF{1,1};
MeanSenFpr = load('m9_MeanSenFpr.mat');
MeanSenFpr = struct2cell(MeanSenFpr);
MeanSenFpr = MeanSenFpr{1,1};

for SopTypeNum = 1:length(MeanSSAAMF)
    TempSeg = MeanSSAAMF{SopTypeNum,1};
    TempEvent = MeanSenFpr{SopTypeNum,1};
    SegmentEvent_ProbabilityWeighted{SopTypeNum,1} = [TempSeg(:,1:6),TempEvent]; %%%%%%%%%
end
save('m10_SegmentEvent','SegmentEvent_ProbabilityWeighted')

%%
toc