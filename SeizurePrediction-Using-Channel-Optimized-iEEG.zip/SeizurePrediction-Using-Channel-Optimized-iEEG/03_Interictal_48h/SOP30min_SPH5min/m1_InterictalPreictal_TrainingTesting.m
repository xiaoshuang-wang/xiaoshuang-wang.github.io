clc
clear
close all
tic

%% Parameters
IDs = {'ID_03';'ID_05';'ID_06';'ID_07';'ID_08';...
    'ID_12';'ID_13';'ID_14';'ID_16';'ID_18'};
NumPatient = length(IDs);
IDSeizures = [3, 4, 7, 4, 4, 7, 7, 4, 4, 5];
fsIndex = [512, 512, 1024, 512, 1024, 1024, 1024, 1024, 1024, 1024];
Path = ['..',filesep,'..',filesep,'Raw_Data',filesep];

InterictalIndex = 1:48; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SOP = 30; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SPH = 5; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Window = 4; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
for PatientNum = [1,3:NumPatient]
    if PatientNum==1 | PatientNum==4
        fs = fsIndex(PatientNum);
    else
        fs = fsIndex(PatientNum)/2;
    end

    %%%%% For Preictal
    Route1 = strcat(Path,IDs{PatientNum,1},filesep,'PreictalSeizure.mat');
    load(Route1)
    NumPreictal = IDSeizures(PatientNum);
    Preictal = [];
    for PreictalNum = 1:NumPreictal
        TmpPreictal = PreictalSeizure(PreictalNum).preictal;
        TmpPreictal = flip(TmpPreictal,2);
        LStart = SPH*60*fs+1;
        LEnd = (SPH+SOP)*60*fs;
        TempPreictal = TmpPreictal(:,LStart:LEnd);
        TempPreictal = flip(TempPreictal,2);
        clear TmpPreictal
        NumPoint = length(TempPreictal);
        NumSegment = NumPoint/(Window*fs);
        for SegmentNum = 1:NumSegment
            LStart = (SegmentNum-1)*Window*fs+1;
            LEnd = SegmentNum*Window*fs;
            PreictalSegment(:,:,SegmentNum) = TempPreictal(:,LStart:LEnd);
        end
        clear TempPreictal
        Preictal{PreictalNum,1} = PreictalSegment;
        clear PreictalSegment;
    end

    %%%%% For Interictal
    Route2 = strcat(Path,IDs{PatientNum,1},filesep,'Interictal',filesep);
    MatInfo = dir(fullfile(Route2,'*.mat'));
    TempMatName = {MatInfo.name}';
    MatName = TempMatName(InterictalIndex);
    InterictalHours = length(InterictalIndex);
    TempInterictal = [];
    for i = 1:InterictalHours
        MatRoute = strcat(Route2,MatName{i,1});
        Tmp = load(MatRoute);
        Tmp = struct2cell(Tmp);
        Tmp = cell2mat(Tmp);
        Tmp = double(Tmp);

        if PatientNum==1 | PatientNum==4
            Temp = Tmp;
            Tmp = [];
        else
            Index = [];
            Index = 1:2:length(Tmp);
            Temp = Tmp(:,Index);
            Tmp = [];
        end
        NumSegment = length(Temp)/(Window*fs);
        for SegmentNum = 1:NumSegment
            LStart = (SegmentNum-1)*Window*fs+1;
            LEnd = SegmentNum*Window*fs;
            InterictalSegment(:,:,SegmentNum) = Temp(:,LStart:LEnd);
        end
        Temp = [];
        TempInterictal = cat(3,TempInterictal,InterictalSegment);
        clear InterictalSegment;
    end

    NumInterictalSegment = size(TempInterictal,3);
    NumSubInterictalSegment = floor(NumInterictalSegment/NumPreictal);
    for n = 1:NumPreictal
        LStart = (n-1)*NumSubInterictalSegment+1;
        LEnd = n*NumSubInterictalSegment;
        Interictal{n,1} = TempInterictal(:,:,LStart:LEnd);
    end
    clear TempInterictal


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%*************** For training and testing ***************%%%
    for PreictalNum = 1:NumPreictal
        Index = [];
        Index = 1:NumPreictal;
        Index(PreictalNum) = [];
        InterictalTraining = [];
        PreictalTraining = [];
        for i = 1:length(Index)
            TmpInterictal = [];
            TmpInterictal = Interictal{Index(i),1};
            Interval = SOP*60/Window;
            InterictalSegmentIndex = [];
            InterictalSegmentIndex = randperm(NumSubInterictalSegment,Interval);
            InterictalTraining = cat(3,InterictalTraining,TmpInterictal(:,:,InterictalSegmentIndex));
            PreictalTraining = cat(3,PreictalTraining,Preictal{Index(i),1});
        end
        NumInterictalTraining = size(InterictalTraining,3);
        InterictalTrainingLabel = [];
        InterictalTrainingLabel = zeros(1,NumInterictalTraining);
        NumPreictalTraining = size(PreictalTraining,3);
        PreictalTrainingLabel = [];
        PreictalTrainingLabel = zeros(1,NumPreictalTraining)+1;
        TempTrainingLabel = [];
        TempTrainingLabel = [InterictalTrainingLabel,PreictalTrainingLabel];
        TempTraining = cat(3,InterictalTraining,PreictalTraining);
        clear InterictalTraining PreictalTraining

        TrainingIndex = [];
        TrainingIndex = randperm(length(TempTrainingLabel));
        TrainingLabel = TempTrainingLabel(TrainingIndex);
        Training = TempTraining(:,:,TrainingIndex);
        clear TempTraining

        TrainTest{1,1} = Training;
        TrainTest{1,2} = TrainingLabel';
        clear Training TrainingLabel

        NumInterictalTesting = size(Interictal{PreictalNum,1},3);
        InterictalTestingLabel = [];
        InterictalTestingLabel = zeros(1,NumInterictalTesting);
        NumPreictalTesting = size(Preictal{PreictalNum,1},3);
        PreictalTestingLabel = [];
        PreictalTestingLabel = zeros(1,NumPreictalTesting)+1;
        TestingLabel = [InterictalTestingLabel,PreictalTestingLabel];
        Testing = cat(3,Interictal{PreictalNum,1},Preictal{PreictalNum,1});

        TrainTest{1,3} = Testing;
        TrainTest{1,4} = TestingLabel';
        clear Testing TestingLabel

        Route = strcat(IDs{PatientNum,1},filesep);
        mkdir(Route);
        save([Route,'Preictal_',int2str(PreictalNum)],'TrainTest')
        clear TrainTest
    end
end

%%
toc