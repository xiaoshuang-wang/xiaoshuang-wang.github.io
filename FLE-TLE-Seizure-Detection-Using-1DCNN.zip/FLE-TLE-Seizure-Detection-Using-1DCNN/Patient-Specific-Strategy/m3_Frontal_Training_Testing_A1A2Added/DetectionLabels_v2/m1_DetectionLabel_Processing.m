clc
clear
close all
tic

%%
targetDir = ['..',filesep,'DetectionLabels_v2',filesep];
contents = dir(targetDir);
FolderNames = {};
for i = 1:length(contents)
    if contents(i).isdir && ~strcmp(contents(i).name,'.') && ~strcmp(contents(i).name,'..')
        FolderNames{end+1,1} = contents(i).name;
    end
end
NumFolder = length(FolderNames(1:4));

%%
for FolderNum = 1:NumFolder
    Path = [FolderNames{FolderNum,1},filesep];
    contents = dir(Path);
    PatientNames = {};
    for i = 1:length(contents)
        if contents(i).isdir && ~strcmp(contents(i).name,'.') && ~strcmp(contents(i).name,'..')
            PatientNames{end+1,1} = contents(i).name;
        end
    end

    NumPatient = length(PatientNames);
    for PatientNum = 1:NumPatient
        Route = [Path,PatientNames{PatientNum,1},filesep];
        Mat = dir(fullfile(Route, '*.mat'));
        MatName = {Mat.name}';
        NumSeizure = length(MatName);
        for SeizureNum = 1:NumSeizure
            SeizurePath = strcat(Route,MatName{SeizureNum,1});
            Labels = load(SeizurePath);
            Labels = struct2cell(Labels);
            Labels = Labels{1,1};
            TrueLabels = squeeze(Labels(:,end,1));
            Index0 = [];
            Index0 = find(TrueLabels==0);
            Index1 = [];
            Index1 = find(TrueLabels==1);
            [NumSeg,NumType,NumRun] = size(Labels);
            for RunNum = 1:NumRun
                PredLabels = zeros(NumSeg,1);
                Probability = Labels(:,1:2,RunNum);
                Indices = [];
                Indices = find(Probability(:,1) <= Probability(:,2));
                PredLabels(Indices) = 1;

                %%%%%******************** Segment-based level ********************%%%%%
                C = confusionmat(TrueLabels,PredLabels,'Order',[0,1]);
                TN = C(1,1); % 真阴性
                FP = C(1,2); % 假阳性
                FN = C(2,1); % 假阴性
                TP = C(2,2); % 真阳性

                Sen = TP/(TP+FN);
                Spec = TN/(TN+FP);
                Acc = (TP+TN)/sum(C(:));
                [fpr,tpr,~,AUC] = perfcurve(TrueLabels,PredLabels,1);

                TempSSAAuc(1,SeizureNum,RunNum) = Sen;
                TempSSAAuc(2,SeizureNum,RunNum) = Spec;
                TempSSAAuc(3,SeizureNum,RunNum) = Acc;
                TempSSAAuc(4,SeizureNum,RunNum) = AUC;

                %%%%%******************** Event-based level ********************%%%%%
                %%%%% for FDR
                Threshold = 3; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input by hands
                Window = 4; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input by hands
                Interval = 30*20; %%% NumSegInOneMintue*NumOfMinutes %%%%%%% Input by hands
                SegmentTime = 2; %%%% Seconds
                PredLabel0 = [];
                PredLabel0 = PredLabels(Index0);
                FDTimes = 0;
                countPred = 0;
                PredFlag = 0;
                for SegNum = Window:length(Index0)
                    Pstart = SegNum-Window+1;
                    Pend = SegNum;

                    if PredFlag == 0
                        ThresholdPred = sum(PredLabel0(Pstart:Pend));
                    else
                        ThresholdPred = 0;
                    end

                    if ThresholdPred >= Threshold
                        PredFlag = 1;
                        FDTimes = FDTimes+1;
                    else
                        if PredFlag == 1
                            countPred = countPred+1;
                            if countPred >= Interval
                                PredFlag = 0;
                                countPred = 0;
                            end
                        end
                    end
                end

                %%%%% for Event-based sensitivity
                PredLabel1 = [];
                PredLabel1 = PredLabels(Index1);
                countPred = 0;
                Latency = 0;
                for SegNum = Window:length(Index1)
                    Pstart = SegNum-Window+1;
                    Pend = SegNum;
                    ThresholdPred = sum(PredLabel1(Pstart:Pend));
                    if ThresholdPred >= Threshold
                        countPred = countPred+1;
                        if countPred == 1
                            Latency = Pend*SegmentTime;
                        end
                    end
                end

                if countPred > 0
                    EventSen = 1;
                else
                    EventSen = 0;
                end

                TempSFdLa(1,SeizureNum,RunNum) = EventSen;
                TempSFdLa(2,SeizureNum,RunNum) = FDTimes;
                TempSFdLa(3,SeizureNum,RunNum) = Latency;
            end
        end
        SSAAuc{PatientNum,FolderNum} = TempSSAAuc;
        TempSSAAuc = [];
        SFdLa{PatientNum,FolderNum} = TempSFdLa;
        TempSFdLa = [];
    end
end
save('m1_SSAAuc','SSAAuc')
save('m1_SFdLa','SFdLa')

%%
toc